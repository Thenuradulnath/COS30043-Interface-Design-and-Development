const app = Vue.createApp({
    data(){
        return{
            units:[]
        };
    },
    mounted(){
        fetch("units.json").then((responce) => responce.jason()).then(data =>(this.units = data)); 
    },
});
app.mount("#app")