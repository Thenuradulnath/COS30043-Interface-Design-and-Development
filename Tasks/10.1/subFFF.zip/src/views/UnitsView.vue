<template>
    <div class="units">
      <Units />
    </div>
  </template>
  
  <script>
  // @ is an alias to /src
  import Units from "@/components/UnitsPage.vue";
  
  export default {
    name: "UnitsView",
    components: {
      Units,
    },
  };
  </script>